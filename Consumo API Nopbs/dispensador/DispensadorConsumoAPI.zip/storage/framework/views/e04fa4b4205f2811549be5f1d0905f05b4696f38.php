<?php $__env->startSection('adminlte_css_pre'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php ( $login_url = View::getSection('login_url') ?? config('adminlte.login_url', 'login') ); ?>
<?php ( $register_url = View::getSection('register_url') ?? config('adminlte.register_url', 'register') ); ?>
<?php ( $password_reset_url = View::getSection('password_reset_url') ?? config('adminlte.password_reset_url', 'password/reset') ); ?>

<?php if(config('adminlte.use_route_url', false)): ?>
    <?php ( $login_url = $login_url ? route($login_url) : '' ); ?>
    <?php ( $register_url = $register_url ? route($register_url) : '' ); ?>
    <?php ( $password_reset_url = $password_reset_url ? route($password_reset_url) : '' ); ?>
<?php else: ?>
    <?php ( $login_url = $login_url ? url($login_url) : '' ); ?>
    <?php ( $register_url = $register_url ? url($register_url) : '' ); ?>
    <?php ( $password_reset_url = $password_reset_url ? url($password_reset_url) : '' ); ?>
<?php endif; ?>

<?php $__env->startSection('auth_header', __('adminlte::adminlte.login_message')); ?>

<?php $__env->startSection('auth_body'); ?>
    <form action="<?php echo e($login_url); ?>" method="post" class="mb-0">
        <?php echo e(csrf_field()); ?>


        
        <div class="input-group mb-3">
            <input type="text" name="nit" class="form-control <?php echo e($errors->has('nit') ? 'is-invalid' : ''); ?>"
                   value="<?php echo e(old('nit')); ?>" placeholder="<?php echo e(__('adminlte::adminlte.nit')); ?>" autofocus>
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-user <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                </div>
            </div>
            <?php if($errors->has('nit')): ?>
                <div class="invalid-feedback">
                    <strong><?php echo e($errors->first('nit')); ?></strong>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="input-group mb-3">
            <input type="password" name="token" id="token" class="form-control <?php echo e($errors->has('token') ? 'is-invalid' : ''); ?>"
                   placeholder="<?php echo e(__('adminlte::adminlte.token')); ?>">
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-eye <?php echo e(config('adminlte.classes_auth_icon', '')); ?>" id="btn-show"></span>
                </div>
            </div>
            <?php if($errors->has('token')): ?>
                <div class="invalid-feedback">
                    <strong><?php echo e($errors->first('token')); ?></strong>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="row">            
            <div class="col-12 mb-1">
                <button type="submit" class="btn btn-block <?php echo e(config('adminlte.classes_auth_btn', 'btn-flat btn-primary')); ?> rounded-lg">
                    <span class="fas fa-sign-in-alt"></span>
                    <?php echo e(__('adminlte::adminlte.sign_in')); ?>

                </button>
            </div>
            <div class="col-12">
                <button type="button" class="btn btn-block btn-flat btn-success rounded-lg" id="btn-service">                    
                    <span class="fab fa-buffer"></span>   
                    <?php echo e(__('adminlte::adminlte.get_service')); ?>                 
                </button>
            </div>
        </div>        
        <?php if($errors->has('validate')): ?>
        <div class="alert alert-danger px-3 py-1">
            <strong>No es posible iniciar sesión</strong>
            <?php if($errors->has('message')): ?>
            <br><span>Este error se presenta por:</span>
            <?php endif; ?>
            <ul>
                <li><?php echo e($errors->first('validate')); ?></li>
                <?php if($errors->has('message')): ?>
                <li><?php echo e($errors->first('message')); ?></li>
                <?php endif; ?>
            </ul>
        </div>
        <?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#btn-show").css('cursor', 'pointer');
    
        $("#btn-show").on("click", function() {
            if ($(this).hasClass('fa-eye')) {
                $(this).removeClass('fa-eye');
                $(this).addClass('fa-eye-slash');
                $("#token").attr('type', 'text');
            }else if ($(this).hasClass('fa-eye-slash')) {
                $(this).removeClass('fa-eye-slash');
                $(this).addClass('fa-eye');
                $("#token").attr('type', 'password');
            }
        });

        $("#btn-service").on("click", function () {
            Swal.fire({
                title: '¡Solicita tu servicio!',
                text: 'Deja tu correo y nos pondremos en contacto contigo:',
                input: 'text',
                inputAttributes: {
                    autocapitalize: 'off'
                },
                showCancelButton: true,
                confirmButtonText: 'Enviar',
                showLoaderOnConfirm: true,
                preConfirm: (login) => {
                    //return fetch(`//api.github.com/users/${login}`)
                    return fetch(``)
                    .then(response => {
                        if (!response.ok) {
                        throw new Error(response.statusText)
                        }
                        return response.json()
                    })
                    .catch(error => {
                        Swal.showValidationMessage(
                        //`Request failed: ${error}`
                        'Servicio en desarrollo'
                        )
                    })
                },
                allowOutsideClick: () => !Swal.isLoading()
                }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                    title: `${result.value.login}'s avatar`,
                    imageUrl: result.value.avatar_url
                    })
                }
            });
        });
    });
</script>
    
<?php echo $__env->make('adminlte::auth.auth-page', ['auth_type' => 'login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Thinking Soft\DispensadorConsumoAPI\resources\views/vendor/adminlte/auth/login.blade.php ENDPATH**/ ?>