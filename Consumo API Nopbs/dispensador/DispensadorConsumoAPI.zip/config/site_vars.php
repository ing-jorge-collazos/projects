<?php
return [
    'urlApi' => 'https://wsmipres.sispro.gov.co/WSSUMMIPRESNOPBS/api/',
    'codSedeIPS' => 'PROV001787'
    //'urlApi' => 'https://tablas.sispro.gov.co/WSSUMMIPRESNOPBS/api/',
];
?>