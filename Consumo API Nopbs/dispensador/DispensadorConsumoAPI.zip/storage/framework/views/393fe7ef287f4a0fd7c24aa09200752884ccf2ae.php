

<?php $__env->startSection('title', 'Suministro API'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="text-center">Resumen</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-light py-3">
    <div class="row">
        <div class="col-md-10 mx-auto">
            <div class="card card-body">
                <div class="container">
                    <div class="table-responsive">
                        <table class="table table-bordered text-center">
                            <thead>
                                <tr>
                                    <th class="align-middle" scope="col">Proceso</th>
                                    <th class="align-middle" scope="col">Cantidad</th>
                                </tr>
                            </thead>
                            <tbody>                               
                                <?php if(count($resumen) > 0): ?> 
                                    <?php $__currentLoopData = $resumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle" scope="col"><?php echo e($item->process_type); ?></td>
                                            <td class="align-middle" scope="col"><?php echo e($item->count); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <h5 class="text-center">No hay registros asociados</h5>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Thinking Soft\DispensadorConsumoAPI\resources\views/session/user.blade.php ENDPATH**/ ?>